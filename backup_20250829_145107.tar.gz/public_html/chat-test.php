<?php
/**
 * Chat API Integration Test v1.0
 * Testa il flusso completo: check → API → increment
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Only POST method allowed']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON input');
    }
    
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'test_chat_flow':
            echo json_encode(testChatFlow($input));
            break;
            
        case 'test_rate_limiting':
            echo json_encode(testRateLimiting($input));
            break;
            
        case 'test_error_handling':
            echo json_encode(testErrorHandling($input));
            break;
            
        case 'test_admin_bypass':
            echo json_encode(testAdminBypass($input));
            break;
            
        case 'simulate_user_journey':
            echo json_encode(simulateUserJourney($input));
            break;
            
        default:
            throw new Exception('Unknown action: ' . $action);
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}

/**
 * Test base del flusso chat integrato
 */
function testChatFlow($data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('a', 64) . '_' . $timestampBase36;
    
    try {
        // Test 1: Messaggio normale con User ID valido
        $chatData = [
            'content' => 'Test message for rate limiting',
            'user_id' => $testUserId
        ];
        
        $chatResponse = makeChatRequest($chatData);
        
        $results['normal_message'] = [
            'http_code' => $chatResponse['http_code'],
            'success' => $chatResponse['http_code'] === 200,
            'response_length' => strlen($chatResponse['body']),
            'has_data_chunks' => substr_count($chatResponse['body'], 'data: ') > 0,
            'contains_limit_info' => strpos($chatResponse['body'], 'limit_notification') !== false
        ];
        
        // Test 2: Messaggio senza User ID
        $noUserIdResponse = makeChatRequest(['content' => 'Test without user id']);
        
        $results['no_user_id'] = [
            'http_code' => $noUserIdResponse['http_code'],
            'properly_rejected' => $noUserIdResponse['http_code'] === 400,
            'error_message' => parseErrorFromResponse($noUserIdResponse['body'])
        ];
        
        // Test 3: Messaggio con User ID invalido
        $invalidUserResponse = makeChatRequest([
            'content' => 'Test with invalid user id',
            'user_id' => 'invalid_user_id'
        ]);
        
        $results['invalid_user_id'] = [
            'http_code' => $invalidUserResponse['http_code'],
            'properly_rejected' => $invalidUserResponse['http_code'] === 400,
            'error_message' => parseErrorFromResponse($invalidUserResponse['body'])
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'chat_flow',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test rate limiting specifico
 */
function testRateLimiting($data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('b', 64) . '_' . $timestampBase36;
    
    try {
        // Invia una serie di messaggi per testare il limite
        $messageResults = [];
        
        for ($i = 1; $i <= 12; $i++) {
            $chatData = [
                'content' => "Test message number $i",
                'user_id' => $testUserId
            ];
            
            $response = makeChatRequest($chatData);
            
            $messageResult = [
                'message_num' => $i,
                'http_code' => $response['http_code'],
                'success' => $response['http_code'] === 200,
                'rate_limited' => $response['http_code'] === 429
            ];
            
            // Se rate limited, estrai dettagli
            if ($response['http_code'] === 429) {
                $errorInfo = json_decode(str_replace('data: ', '', $response['body']), true);
                $messageResult['limit_details'] = [
                    'status' => $errorInfo['status'] ?? 'unknown',
                    'count' => $errorInfo['count'] ?? 0,
                    'max_count' => $errorInfo['max_count'] ?? 10,
                    'message' => $errorInfo['message'] ?? ''
                ];
                
                // Dopo il primo rate limit, interrompi
                break;
            }
            
            $messageResults[] = $messageResult;
            
            // Breve pausa per evitare problemi di concorrenza
            usleep(100000); // 0.1 secondi
        }
        
        $results['message_sequence'] = $messageResults;
        
        // Analizza quando è scattato il rate limiting
        $rateLimitedAt = null;
        foreach ($messageResults as $msg) {
            if ($msg['rate_limited']) {
                $rateLimitedAt = $msg['message_num'];
                break;
            }
        }
        
        $results['rate_limit_analysis'] = [
            'total_sent' => count($messageResults),
            'rate_limited_at_message' => $rateLimitedAt,
            'rate_limiting_working' => $rateLimitedAt !== null && $rateLimitedAt <= 11
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'rate_limiting',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test gestione errori
 */
function testErrorHandling($data) {
    $results = [];
    
    try {
        // Test 1: JSON malformato
        $malformedResponse = makeChatRequestRaw('invalid json {');
        $results['malformed_json'] = [
            'http_code' => $malformedResponse['http_code'],
            'properly_rejected' => $malformedResponse['http_code'] === 400
        ];
        
        // Test 2: Contenuto vuoto
        $jsTimestamp = round(microtime(true) * 1000);
        $timestampBase36 = base_convert($jsTimestamp, 10, 36);
        $emptyContentResponse = makeChatRequest(['user_id' => 'fp_' . str_repeat('c', 64) . '_' . $timestampBase36]);
        $results['empty_content'] = [
            'http_code' => $emptyContentResponse['http_code'],
            'properly_rejected' => $emptyContentResponse['http_code'] === 400
        ];
        
        // Test 3: Metodo GET (dovrebbe fallire)
        $getResponse = makeChatRequest([], 'GET');
        $results['wrong_method'] = [
            'http_code' => $getResponse['http_code'],
            'properly_rejected' => $getResponse['http_code'] === 405
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'error_handling',
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test admin bypass
 */
function testAdminBypass($data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('d', 64) . '_' . $timestampBase36;
    
    try {
        // Prima porta l'utente al limite
        for ($i = 1; $i <= 10; $i++) {
            makeChatRequest([
                'content' => "Setup message $i",
                'user_id' => $testUserId
            ]);
        }
        
        // Ora dovrebbe essere rate limited
        $blockedResponse = makeChatRequest([
            'content' => 'This should be blocked',
            'user_id' => $testUserId
        ]);
        
        $results['blocked_without_bypass'] = [
            'http_code' => $blockedResponse['http_code'],
            'properly_blocked' => $blockedResponse['http_code'] === 429
        ];
        
        // Genera token admin valido
        $adminToken = hash_hmac('sha256', 
            date('Y-m-d') . $testUserId, 
            'rentria_admin_secret_2025_' . $_SERVER['SERVER_NAME']
        );
        
        // Test con admin bypass
        $bypassResponse = makeChatRequest([
            'content' => 'This should work with bypass',
            'user_id' => $testUserId,
            'admin_bypass' => $adminToken
        ]);
        
        $results['with_admin_bypass'] = [
            'http_code' => $bypassResponse['http_code'],
            'bypass_worked' => $bypassResponse['http_code'] === 200,
            'response_length' => strlen($bypassResponse['body'])
        ];
        
        // Test con token invalido
        $invalidBypassResponse = makeChatRequest([
            'content' => 'This should still be blocked',
            'user_id' => $testUserId,
            'admin_bypass' => 'invalid_token'
        ]);
        
        $results['invalid_bypass_token'] = [
            'http_code' => $invalidBypassResponse['http_code'],
            'properly_blocked' => $invalidBypassResponse['http_code'] === 429
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'admin_bypass',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Simula journey completo di un utente
 */
function simulateUserJourney($data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('e', 64) . '_' . $timestampBase36;
    
    try {
        $journey = [];
        
        // Fase 1: Primi messaggi (dovrebbero funzionare)
        for ($i = 1; $i <= 5; $i++) {
            $response = makeChatRequest([
                'content' => "User journey message $i",
                'user_id' => $testUserId
            ]);
            
            $journey[] = [
                'step' => "message_$i",
                'http_code' => $response['http_code'],
                'success' => $response['http_code'] === 200
            ];
        }
        
        // Fase 2: Avvicinamento al limite (6-10)
        for ($i = 6; $i <= 10; $i++) {
            $response = makeChatRequest([
                'content' => "Approaching limit message $i",
                'user_id' => $testUserId
            ]);
            
            $hasLimitNotification = strpos($response['body'], 'limit_notification') !== false;
            
            $journey[] = [
                'step' => "limit_approach_$i",
                'http_code' => $response['http_code'],
                'success' => $response['http_code'] === 200,
                'has_limit_notification' => $hasLimitNotification
            ];
        }
        
        // Fase 3: Oltre il limite (dovrebbe essere bloccato)
        $response = makeChatRequest([
            'content' => 'This should be blocked',
            'user_id' => $testUserId
        ]);
        
        $journey[] = [
            'step' => 'beyond_limit',
            'http_code' => $response['http_code'],
            'blocked' => $response['http_code'] === 429,
            'error_details' => parseErrorFromResponse($response['body'])
        ];
        
        $results['user_journey'] = $journey;
        
        // Analisi journey
        $successfulMessages = array_filter($journey, function($step) {
            return $step['success'] ?? false;
        });
        
        $results['journey_analysis'] = [
            'total_steps' => count($journey),
            'successful_messages' => count($successfulMessages),
            'blocked_at_correct_limit' => end($journey)['blocked'] ?? false,
            'journey_completed_correctly' => count($successfulMessages) === 10 && (end($journey)['blocked'] ?? false)
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'user_journey',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Helper: Fa richiesta al chat API
 */
function makeChatRequest($data, $method = 'POST') {
    $url = 'https://lightbot.rentri360.it/chat.php';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    } else {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'body' => $response,
        'http_code' => $httpCode
    ];
}

/**
 * Helper: Fa richiesta con body raw
 */
function makeChatRequestRaw($rawBody) {
    $url = 'https://lightbot.rentri360.it/chat.php';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $rawBody);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'body' => $response,
        'http_code' => $httpCode
    ];
}

/**
 * Helper: Estrae errore da response
 */
function parseErrorFromResponse($responseBody) {
    if (strpos($responseBody, 'data: ') === 0) {
        $jsonStr = str_replace('data: ', '', $responseBody);
        $decoded = json_decode($jsonStr, true);
        return $decoded['message'] ?? 'Unknown error';
    }
    
    return 'Could not parse error';
}

?>