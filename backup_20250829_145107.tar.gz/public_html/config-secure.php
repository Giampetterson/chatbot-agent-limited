<?php
// File di configurazione sicuro per API keys
// Questo file deve essere protetto e non accessibile via web

// OpenAI API Key per Whisper
define('OPENAI_API_KEY', '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');

// Percorso sicuro per il file di contesto
define('CONTEXT_FILE_PATH', __DIR__ . '/contesto.txt');

// Altre configurazioni di sicurezza
define('MAX_AUDIO_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_AUDIO_TYPES', ['audio/webm', 'audio/ogg', 'audio/mp4', 'audio/mpeg', 'audio/wav']);

?>