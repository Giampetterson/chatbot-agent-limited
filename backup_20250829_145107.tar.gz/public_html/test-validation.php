<?php
/**
 * Test endpoint per validazione User ID
 * Usato dalla pagina fingerprint-test.html
 */

require_once 'user-validator.php';

// Headers per CORS e JSON
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Solo POST accettato
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Only POST method allowed']);
    exit;
}

try {
    // Get input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON input');
    }
    
    if (!isset($data['user_id'])) {
        throw new Exception('Missing user_id parameter');
    }
    
    $userId = $data['user_id'];
    
    // Rate limiting check
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!UserValidator::checkValidationRate($clientIp)) {
        http_response_code(429);
        echo json_encode([
            'error' => 'Rate limit exceeded',
            'message' => 'Too many validation requests'
        ]);
        exit;
    }
    
    // Test validation
    $isValid = UserValidator::validateUserId($userId);
    $sanitized = UserValidator::sanitizeUserId($userId);
    $parsed = UserValidator::parseUserId($userId);
    $storageHash = UserValidator::hashForStorage($userId);
    $isExpired = UserValidator::isExpired($userId);
    
    // Log validation attempt
    UserValidator::logValidation($userId, $isValid, $clientIp);
    
    // Response
    $response = [
        'success' => true,
        'user_id' => $userId,
        'valid' => $isValid,
        'sanitized' => $sanitized,
        'parsed' => $parsed,
        'storage_hash' => $storageHash,
        'is_expired' => $isExpired,
        'tests' => [
            'format_check' => preg_match('/^fp_[a-f0-9]{64}_[a-z0-9]+$/', $userId),
            'length_check' => strlen($userId) >= 50 && strlen($userId) <= 200,
            'hash_length' => strlen(explode('_', $userId)[1] ?? '') === 64,
            'timestamp_valid' => $parsed !== null
        ],
        'client_info' => [
            'ip' => $clientIp,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'timestamp' => date('Y-m-d H:i:s')
        ]
    ];
    
    echo json_encode($response, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}
?>