<?php
/**
 * Test endpoint per RateLimiter Service
 * Testa tutti i metodi e scenari del rate limiting
 */

require_once 'rate-limiter.php';

// Headers per JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Solo POST accettato
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Only POST method allowed']);
    exit;
}

try {
    // Get input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON input');
    }
    
    $action = $data['action'] ?? '';
    
    // Inizializza rate limiter
    $rateLimiter = new RateLimiter();
    
    switch ($action) {
        case 'test_basic_methods':
            echo json_encode(testBasicMethods($rateLimiter, $data));
            break;
            
        case 'test_10_message_limit':
            echo json_encode(test10MessageLimit($rateLimiter, $data));
            break;
            
        case 'test_grace_period':
            echo json_encode(testGracePeriod($rateLimiter, $data));
            break;
            
        case 'test_admin_bypass':
            echo json_encode(testAdminBypass($rateLimiter, $data));
            break;
            
        case 'test_error_handling':
            echo json_encode(testErrorHandling($rateLimiter, $data));
            break;
            
        case 'get_system_stats':
            echo json_encode($rateLimiter->getSystemStats());
            break;
            
        case 'check_limit':
            $userId = $data['user_id'] ?? '';
            $adminBypass = $data['admin_bypass'] ?? null;
            echo json_encode($rateLimiter->checkLimit($userId, $adminBypass));
            break;
            
        case 'increment_usage':
            $userId = $data['user_id'] ?? '';
            $adminBypass = $data['admin_bypass'] ?? null;
            echo json_encode($rateLimiter->incrementUsage($userId, $adminBypass));
            break;
            
        case 'is_blocked':
            $userId = $data['user_id'] ?? '';
            echo json_encode($rateLimiter->isBlocked($userId));
            break;
            
        case 'get_user_stats':
            $userId = $data['user_id'] ?? '';
            echo json_encode($rateLimiter->getUserStats($userId));
            break;
            
        default:
            throw new Exception('Unknown action: ' . $action);
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}

/**
 * Test metodi base del RateLimiter
 */
function testBasicMethods($rateLimiter, $data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('1', 64) . '_' . $timestampBase36;
    
    try {
        // Test 1: checkLimit nuovo utente
        $checkResult = $rateLimiter->checkLimit($testUserId);
        $results['check_new_user'] = [
            'success' => $checkResult['status'] === 'allowed',
            'can_send' => $checkResult['can_send'],
            'count' => $checkResult['count'],
            'status' => $checkResult['status']
        ];
        
        // Test 2: incrementUsage
        $incrementResult = $rateLimiter->incrementUsage($testUserId);
        $results['increment_usage'] = [
            'success' => $incrementResult['can_send'] && isset($incrementResult['data']['incremented']),
            'count_after' => $incrementResult['count'],
            'status' => $incrementResult['status'],
            'incremented' => $incrementResult['data']['incremented'] ?? false
        ];
        
        // Test 3: isBlocked
        $blockedResult = $rateLimiter->isBlocked($testUserId);
        $results['is_blocked'] = [
            'success' => $blockedResult['status'] === 'allowed',
            'is_blocked' => !$blockedResult['can_send'],
            'status' => $blockedResult['status']
        ];
        
        // Test 4: getUserStats
        $statsResult = $rateLimiter->getUserStats($testUserId);
        $results['get_user_stats'] = [
            'success' => isset($statsResult['data']['user_record']),
            'count' => $statsResult['count'],
            'remaining' => $statsResult['data']['remaining_messages'] ?? null,
            'usage_percentage' => $statsResult['data']['usage_percentage'] ?? null
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'basic_methods',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test limite esatto di 10 messaggi
 */
function test10MessageLimit($rateLimiter, $data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('2', 64) . '_' . $timestampBase36;
    
    try {
        // Invia esattamente 10 messaggi
        $messageResults = [];
        
        for ($i = 1; $i <= 12; $i++) { // Testa fino a 12 per verificare blocco
            $checkResult = $rateLimiter->checkLimit($testUserId);
            
            $messageResult = [
                'message_num' => $i,
                'check_status' => $checkResult['status'],
                'can_send_before' => $checkResult['can_send'],
                'count_before' => $checkResult['count']
            ];
            
            if ($checkResult['can_send']) {
                $incrementResult = $rateLimiter->incrementUsage($testUserId);
                $messageResult['increment_status'] = $incrementResult['status'];
                $messageResult['count_after'] = $incrementResult['count'];
                $messageResult['incremented'] = $incrementResult['data']['incremented'] ?? false;
                
                // Verifica stato dopo 10° messaggio
                if ($i === 10) {
                    $afterLimitCheck = $rateLimiter->checkLimit($testUserId);
                    $messageResult['after_limit_status'] = $afterLimitCheck['status'];
                    $messageResult['after_limit_can_send'] = $afterLimitCheck['can_send'];
                }
            } else {
                $messageResult['blocked'] = true;
                $messageResult['block_reason'] = $checkResult['message'];
            }
            
            $messageResults[] = $messageResult;
            
            // Se bloccato permanentemente, esci
            if ($checkResult['status'] === 'permanently_blocked') {
                break;
            }
        }
        
        $results['message_sequence'] = $messageResults;
        
        // Test finale: verifica stato dopo limite
        $finalCheck = $rateLimiter->isBlocked($testUserId);
        $results['final_state'] = [
            'is_blocked' => !$finalCheck['can_send'],
            'final_count' => $finalCheck['count'],
            'status' => $finalCheck['status']
        ];
        
        // Verifica che il limite sia esattamente 10
        $results['limit_validation'] = [
            'reached_exactly_10' => $finalCheck['count'] >= 10,
            'blocked_after_10' => $finalCheck['status'] !== 'allowed'
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => '10_message_limit',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test grace period di 1 minuto
 */
function testGracePeriod($rateLimiter, $data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('3', 64) . '_' . $timestampBase36;
    
    try {
        // Porta utente a 10 messaggi
        for ($i = 1; $i <= 10; $i++) {
            $rateLimiter->incrementUsage($testUserId);
        }
        
        // Verifica stato appena raggiunto il limite
        $atLimitCheck = $rateLimiter->checkLimit($testUserId);
        $results['at_limit_state'] = [
            'status' => $atLimitCheck['status'],
            'can_send' => $atLimitCheck['can_send'],
            'message' => $atLimitCheck['message'],
            'grace_remaining' => $atLimitCheck['data']['grace_remaining_minutes'] ?? null
        ];
        
        // Test durante grace period (simula)
        $duringGraceCheck = $rateLimiter->checkLimit($testUserId);
        $results['during_grace'] = [
            'status' => $duringGraceCheck['status'],
            'can_send' => $duringGraceCheck['can_send'],
            'is_grace_period' => $duringGraceCheck['status'] === 'grace_period'
        ];
        
        // Simula passaggio del tempo (per test reali bisognerebbe aspettare)
        // In un test reale qui si aspetterebbe 1+ minuti
        
        // Test isBlocked per verifica logica
        $blockedCheck = $rateLimiter->isBlocked($testUserId);
        $results['blocked_check'] = [
            'status' => $blockedCheck['status'],
            'can_send' => $blockedCheck['can_send']
        ];
        
        // Verifica struttura response grace period
        $results['grace_period_features'] = [
            'has_remaining_time' => isset($atLimitCheck['data']['grace_remaining_minutes']),
            'proper_status_code' => in_array($atLimitCheck['status'], ['grace_period', 'limit_reached']),
            'message_indicates_grace' => strpos($atLimitCheck['message'], 'minuto') !== false
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'grace_period',
        'test_user_id' => $testUserId,
        'note' => 'Grace period timing requires real-time test for full validation',
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test admin bypass
 */
function testAdminBypass($rateLimiter, $data) {
    $results = [];
    // Genera timestamp JavaScript in millisecondi
    $jsTimestamp = round(microtime(true) * 1000);
    $timestampBase36 = base_convert($jsTimestamp, 10, 36);
    $testUserId = 'fp_' . str_repeat('4', 64) . '_' . $timestampBase36;
    
    try {
        // Genera admin token valido
        $validAdminToken = hash_hmac('sha256', 
            date('Y-m-d') . $testUserId, 
            'rentria_admin_secret_2025_' . $_SERVER['SERVER_NAME']
        );
        
        $results['token_generation'] = [
            'token_generated' => !empty($validAdminToken),
            'token_length' => strlen($validAdminToken)
        ];
        
        // Test con token valido
        $validBypassCheck = $rateLimiter->checkLimit($testUserId, $validAdminToken);
        $results['valid_bypass'] = [
            'accepted' => $validBypassCheck['can_send'],
            'status' => $validBypassCheck['status'],
            'is_admin_bypass' => $validBypassCheck['data']['admin_bypass'] ?? false
        ];
        
        // Test con token invalido
        $invalidBypassCheck = $rateLimiter->checkLimit($testUserId, 'invalid_token');
        $results['invalid_bypass'] = [
            'rejected' => !isset($invalidBypassCheck['data']['admin_bypass']),
            'status' => $invalidBypassCheck['status']
        ];
        
        // Test increment con bypass
        $bypassIncrement = $rateLimiter->incrementUsage($testUserId, $validAdminToken);
        $results['bypass_increment'] = [
            'success' => $bypassIncrement['can_send'],
            'increment_skipped' => $bypassIncrement['data']['increment_skipped'] ?? false,
            'is_admin_bypass' => $bypassIncrement['data']['admin_bypass'] ?? false
        ];
        
        // Test reset user
        $resetResult = $rateLimiter->resetUser($testUserId, $validAdminToken);
        $results['reset_user'] = [
            'success' => $resetResult['can_send'],
            'status' => $resetResult['status'],
            'is_admin_reset' => $resetResult['data']['admin_reset'] ?? false
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'admin_bypass',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test gestione errori
 */
function testErrorHandling($rateLimiter, $data) {
    $results = [];
    
    try {
        // Test 1: User ID invalido
        $invalidUserCheck = $rateLimiter->checkLimit('invalid_user_id');
        $results['invalid_user_id'] = [
            'properly_rejected' => $invalidUserCheck['status'] === 'invalid_user',
            'status' => $invalidUserCheck['status'],
            'message' => $invalidUserCheck['message']
        ];
        
        // Test 2: User ID vuoto
        $emptyUserCheck = $rateLimiter->checkLimit('');
        $results['empty_user_id'] = [
            'properly_rejected' => $emptyUserCheck['status'] === 'invalid_user',
            'status' => $emptyUserCheck['status']
        ];
        
        // Test 3: User ID null
        $nullUserCheck = $rateLimiter->checkLimit(null);
        $results['null_user_id'] = [
            'properly_rejected' => $nullUserCheck['status'] === 'invalid_user',
            'status' => $nullUserCheck['status']
        ];
        
        // Test 4: Verifica che tutti i metodi gestiscano errori
        // Genera timestamp JavaScript in millisecondi
        $jsTimestamp = round(microtime(true) * 1000);
        $timestampBase36 = base_convert($jsTimestamp, 10, 36);
        $validUserId = 'fp_' . str_repeat('5', 64) . '_' . $timestampBase36;
        
        $methods = [
            'checkLimit' => $rateLimiter->checkLimit($validUserId),
            'incrementUsage' => $rateLimiter->incrementUsage($validUserId),
            'isBlocked' => $rateLimiter->isBlocked($validUserId),
            'getUserStats' => $rateLimiter->getUserStats($validUserId)
        ];
        
        $results['method_responses'] = [];
        foreach ($methods as $methodName => $response) {
            $results['method_responses'][$methodName] = [
                'has_status' => isset($response['status']),
                'has_timestamp' => isset($response['timestamp']),
                'has_message' => isset($response['message']),
                'status' => $response['status'] ?? 'unknown'
            ];
        }
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'error_handling',
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

?>