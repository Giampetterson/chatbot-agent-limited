# 🤖 RentrIA Chat System v2.2.0

Sistema di assistente virtuale AI completo, autoconsistente e specializzato nella gestione dei rifiuti e sistema RENTRI, con analisi immagini AI integrata e funzionalità avanzate multi-piattaforma.

## 🏗️ Architettura

Il sistema è composto da tre componenti principali:

- **🌐 Web Chat Interface**: Interfaccia web moderna con streaming real-time + **analisi immagini AI**
- **📱 WordPress Plugin**: Widget integrato per siti WordPress  
- **🤖 Telegram Bot**: Bot per gruppo Telegram con polling HTTP
- **🔬 Analisi Immagini**: Sistema integrato di riconoscimento rifiuti con GPT-4o Vision

## 🚀 Deployment

### Web Interface
- **URL**: `https://chatbot-test.piattaformarentrifacile.it/`
- **Backend**: PHP 8.4 + Nginx con SSL/TLS
- **Features**: Streaming SSE, Export PDF, Sistema Note, Condivisione Social, **Messaggi Vocali**, **Analisi Immagini AI**

### Telegram Bot  
- **Bot**: `@RentriFacileBot`
- **Gruppo**: `@RentriFacile`
- **Modalità**: HTTP Polling (no HTTPS richiesto)

## 📁 Struttura File

```
rentri-chat/
├── index.html                    # Landing page con auto-redirect
├── chatbot.html                 # Interfaccia chat principale  
├── chat.php                     # API backend con streaming SSE
├── notes.js                     # Sistema note con gestione immagini
├── services.js                  # Servizi e utility
├── rentri-chat-widget/         # Plugin WordPress
│   ├── rentri-chat-widget.php  # Core plugin
│   └── assets/
│       ├── rentri-chat.css     # Stili widget
│       └── rentri-chat.js      # Logica frontend widget
└── telegram-bot/              # Sistema bot Telegram
    ├── config.php              # Configurazione bot
    ├── polling-bot.php         # Bot con polling HTTP
    ├── webhook.php             # Handler webhook (alternativo)
    ├── bot-functions.php       # Funzioni core bot
    └── start-bot.sh           # Script avvio automatico
```

## 🔧 Configurazione

### API AI
- **Endpoint**: `https://agents.do-ai.run/api/v1/chat/completions`
- **Streaming**: Server-Sent Events (SSE)
- **Specializzazione**: Gestione rifiuti, codici CER, normative RENTRI

### Nginx Configuration
- **Path**: `/etc/nginx/sites-available/chatbot-test.piattaformarentrifacile.it`
- **Domain**: `chatbot-test.piattaformarentrifacile.it` con SSL Let's Encrypt
- **PHP**: PHP-FPM 8.4 con streaming ottimizzato
- **SSL**: Certificato Let's Encrypt con auto-renewal

### Telegram Bot
- **Modalità**: HTTP Polling (background process)
- **Auto-start**: Configurato via crontab
- **Comandi**: `/start`, `/help`, `/info`, `/contatti`

## 🆕 Aggiornamenti v2.2.0

### 🔬 **Analisi Immagini AI Integrata** 
- **Riconoscimento automatico rifiuti** con GPT-4o Vision
- **Classificazione materiali** (plastica, vetro, carta, metallo, organico, etc.)
- **Conteggio oggetti** e stima peso per modulistica RENTRI  
- **Interfaccia unificata** nel menu attachment della chat
- **Sistema autoconsistente** - nessuna dipendenza esterna

### 🧹 **Ottimizzazioni Sistema**
- **Progetto ripulito** - rimossi file obsoleti e di test
- **Cache ottimizzata** per aggiornamenti mobile immediati
- **Documentazione aggiornata** per tutte le componenti
- **Codebase consolidato** - tutto in una directory

## ✨ Features Complete

### Web Interface
- **🎨 Design Modern**: Space Grotesk + Oxanium fonts, colori aziendali
- **⚡ Real-time Streaming**: Risposte progressive con SSE  
- **📄 Export PDF**: Multi-pagina con branding automatico
- **📱 Condivisione Social**: WhatsApp/Telegram con device detection
- **🎤 Messaggi Vocali** (NEW v2.2.0):
  - Registrazione audio con MediaRecorder API
  - Trascrizione automatica con OpenAI Whisper
  - Supporto browser moderni (Chrome, Firefox, Edge)
  - Feedback visivo durante registrazione
- **📝 Sistema Note**: 
  - Drag & drop tra dossier
  - Organizzazione automatica con dossier
  - Export TXT/CSV avanzato
  - **🖼️ Gestione Immagini** (NEW):
    - Upload multiplo con drag & drop
    - Compressione automatica (Canvas API, max 1024px)
    - Gallery con navigazione keyboard
    - Formato WebP/JPEG ottimizzato
    - Thumbnail con informazioni dimensioni
- **🎯 Responsive**: Mobile-first, touch-optimized
- **📱 Layout Ottimizzato** (NEW):
  - Form su due righe per massimizzare spazio input
  - PDF button sempre visibile in portrait/landscape
  - Pulsanti con stile unificato e font consistenti

### WordPress Plugin  
- **🔧 Shortcode**: `[rentri_chat]` con parametri personalizzabili
- **⚙️ Admin Panel**: Configurazione API keys e impostazioni
- **🎨 Customizable**: Override CSS, parametri shortcode
- **🔄 Multi-instance**: Supporto widget multipli nella stessa pagina

### Telegram Bot
- **💬 AI Integration**: Risposte con streaming via menzioni `@RentriFacileBot`  
- **📝 Markdown Support**: Conversione intelligente per compatibilità Telegram
- **✏️ Edit Messages**: Sistema "⏳ Elaborando..." sostituito con risposta finale
- **🔧 Commands**: Sistema comandi completo con help integrato
- **📊 Monitoring**: Log dettagliati e sistema di debug

## 🛠️ Manutenzione

### Controllo Servizi
```bash
# Web server
systemctl status nginx
systemctl status php8.4-fpm

# Bot Telegram  
ps aux | grep polling-bot.php
tail -f telegram-bot/logs/bot-output.log

# Test API
curl -X POST https://chatbot-test.piattaformarentrifacile.it/chat.php \
  -H "Content-Type: application/json" \
  -d '{"content":"test"}'
```

### Management Bot
```bash
cd telegram-bot/
./start-bot.sh    # Avvia bot
./stop-bot.sh     # Ferma bot
```

## 🔐 Sicurezza

- **Input Validation**: Sanitizzazione completa input utente
- **API Protection**: Header authorization, rate limiting  
- **Error Handling**: Graceful degradation, no sensitive data exposure
- **Headers Security**: X-Frame-Options, X-XSS-Protection, X-Content-Type-Options
- **Log Management**: Comprehensive debugging senza credenziali

## 🎯 Specializzazione Dominio

Il sistema è ottimizzato per:
- **♻️ Gestione Rifiuti**: Classificazione, codici CER, normative ambientali
- **📋 Sistema RENTRI**: Procedure, moduli, compliance  
- **🏢 Supporto Professionale**: Linguaggio tecnico, riferimenti normativi precisi

## 📈 Monitoring

- **🔍 Debug Mode**: Attivabile in `telegram-bot/config.php`
- **📊 Logs**: Structured logging con timestamp e livelli
- **⚡ Performance**: Memory usage e response time tracking
- **🚨 Error Tracking**: Multi-layer fallbacks con alerting

## 📝 Changelog

### v2.2.0 (Latest) - 2024
- **🎤 Sistema Messaggi Vocali**:
  - Integrazione OpenAI Whisper per trascrizione
  - Pulsante microfono nell'interfaccia chat
  - Registrazione con feedback visivo (pulse animation)
  - Trascrizione automatica in italiano
  - Gestione permessi microfono browser
  - File dedicati: `voice-recorder.js`, `voice-transcription.php`
- **🔒 Migrazione HTTPS**:
  - Dominio: `chatbot-test.piattaformarentrifacile.it`
  - Certificato SSL Let's Encrypt
  - Configurazione Nginx ottimizzata per HTTPS
  - CORS headers per API endpoints

### v2.1.0 - 2024
- **🖼️ Sistema Gestione Immagini per Note**:
  - Upload multiplo con drag & drop
  - Compressione automatica intelligente (max 1024px, quality 0.8)
  - Gallery viewer con navigazione keyboard (←/→/ESC)
  - Supporto WebP con fallback JPEG
  - Thumbnails con info dimensioni
  - Storage Base64 in localStorage
- **📱 Miglioramenti Mobile UX**:
  - Layout form su due righe (input+send | notes+pdf)
  - Fix visibilità PDF button in portrait mode
  - Media queries ottimizzate per schermi <480px e <360px
- **🎨 UI/UX Refinements**:
  - Unificazione stili pulsanti con font 'Space Grotesk'
  - Dimensioni consistenti (11px font, 4px 10px padding, 12px border-radius)
  - Fix pluralizzazione italiano (immagine/immagini)
  - Cambio testi expand/collapse ("Espandi"/"Restringi")
  - Titolo semplificato da "Appunti e Dossier" a "Note"
- **🐛 Bug Fixes**:
  - Risolto problema icona copy button non visibile
  - Fix gallery collapse behavior
  - Corretti sizing pulsanti troppo grandi

### v2.0.0 - 2024
- Sistema Note completo con dossier
- Export PDF multi-pagina
- Condivisione social WhatsApp/Telegram
- WordPress plugin integration
- Telegram bot con polling HTTP

## 🤝 Contributing

1. Clone repository
2. Setup environment locale  
3. Test modifiche su development
4. Submit pull request

## 📄 License

Proprietary - RentrIA © 2024

---

*🤖 Sviluppato con Claude Code per PiattaformaRentriFacile.it*
