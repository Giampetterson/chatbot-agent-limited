<?php
/**
 * Test endpoint per sistema storage
 * Tests per creazione, lettura, concorrenza, integrità
 */

require_once 'user-storage.php';

// Headers per JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Solo POST accettato
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Only POST method allowed']);
    exit;
}

try {
    // Get input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON input');
    }
    
    $action = $data['action'] ?? '';
    
    // Inizializza storage
    $storage = new UserStorage();
    
    switch ($action) {
        case 'test_basic_operations':
            echo json_encode(testBasicOperations($storage));
            break;
            
        case 'test_user_lifecycle':
            echo json_encode(testUserLifecycle($storage, $data));
            break;
            
        case 'test_concurrency':
            echo json_encode(testConcurrency($storage, $data));
            break;
            
        case 'test_data_integrity':
            echo json_encode(testDataIntegrity($storage));
            break;
            
        case 'test_admin_functions':
            echo json_encode(testAdminFunctions($storage, $data));
            break;
            
        case 'get_stats':
            echo json_encode([
                'success' => true,
                'stats' => $storage->getStorageStats(),
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            break;
            
        default:
            throw new Exception('Unknown action: ' . $action);
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}

/**
 * Test operazioni base storage
 */
function testBasicOperations($storage) {
    $results = [];
    
    try {
        // Test 1: Creazione nuovo utente
        $testUserId = 'fp_' . str_repeat('a', 64) . '_' . base_convert(time() * 1000, 10, 36);
        $record = $storage->getUserRecord($testUserId);
        
        $results['create_user'] = [
            'success' => true,
            'user_created' => $record['count'] === 0,
            'record' => $record
        ];
        
        // Test 2: Check can send message
        $canSend = $storage->canUserSendMessage($testUserId);
        
        $results['check_can_send'] = [
            'success' => true,
            'can_send' => $canSend['can_send'],
            'reason' => $canSend['reason'],
            'remaining' => $canSend['remaining'] ?? null
        ];
        
        // Test 3: Increment counter
        $incrementedRecord = $storage->incrementUserMessageCount($testUserId);
        
        $results['increment_counter'] = [
            'success' => true,
            'count_after' => $incrementedRecord['count'],
            'first_message_set' => !empty($incrementedRecord['first_message'])
        ];
        
        // Test 4: Stats
        $stats = $storage->getStorageStats();
        
        $results['get_stats'] = [
            'success' => true,
            'total_users' => $stats['total_users'],
            'file_exists' => $stats['file_size'] > 0
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'basic_operations',
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test ciclo di vita completo utente
 */
function testUserLifecycle($storage, $data) {
    $results = [];
    
    try {
        $testUserId = $data['test_user_id'] ?? ('fp_' . str_repeat('b', 64) . '_' . base_convert(time() * 1000, 10, 36));
        
        // Simula invio di 10+ messaggi
        $results['messages'] = [];
        
        for ($i = 1; $i <= 12; $i++) {
            // Check se può inviare
            $canSend = $storage->canUserSendMessage($testUserId);
            
            $messageResult = [
                'message_num' => $i,
                'can_send_before' => $canSend['can_send'],
                'reason' => $canSend['reason'],
                'count_before' => $canSend['count']
            ];
            
            if ($canSend['can_send']) {
                // Incrementa
                $record = $storage->incrementUserMessageCount($testUserId);
                $messageResult['count_after'] = $record['count'];
                $messageResult['incremented'] = true;
                
                // Se è il 10°, simula attesa grace period
                if ($i === 10) {
                    sleep(1); // Simula 1 secondo (per test)
                }
                
            } else {
                $messageResult['incremented'] = false;
                $messageResult['blocked_reason'] = $canSend['message'] ?? 'Unknown';
                
                // Se bloccato definitivamente, esci dal loop
                if ($canSend['reason'] === 'permanently_blocked') {
                    break;
                }
            }
            
            $results['messages'][] = $messageResult;
        }
        
        // Check stato finale
        $finalCheck = $storage->canUserSendMessage($testUserId);
        $results['final_state'] = [
            'can_send' => $finalCheck['can_send'],
            'reason' => $finalCheck['reason'],
            'final_count' => $finalCheck['count']
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'user_lifecycle',
        'test_user_id' => $testUserId,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test concorrenza multiple richieste
 */
function testConcurrency($storage, $data) {
    $results = [];
    
    try {
        $testUserId = $data['test_user_id'] ?? ('fp_' . str_repeat('c', 64) . '_' . base_convert(time() * 1000, 10, 36));
        $iterations = $data['iterations'] ?? 5;
        
        // Simula multiple richieste simultanee
        $startTime = microtime(true);
        
        for ($i = 0; $i < $iterations; $i++) {
            $canSend = $storage->canUserSendMessage($testUserId);
            
            if ($canSend['can_send']) {
                $storage->incrementUserMessageCount($testUserId);
            }
            
            $results['iteration_' . $i] = [
                'can_send' => $canSend['can_send'],
                'count' => $canSend['count']
            ];
        }
        
        $endTime = microtime(true);
        
        // Check stato finale
        $finalRecord = $storage->getUserRecord($testUserId);
        
        $results['performance'] = [
            'total_time_ms' => round(($endTime - $startTime) * 1000, 2),
            'avg_time_per_op_ms' => round(($endTime - $startTime) * 1000 / $iterations, 2),
            'final_count' => $finalRecord['count']
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'concurrency',
        'iterations' => $iterations,
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test integrità dati
 */
function testDataIntegrity($storage) {
    $results = [];
    
    try {
        // Test 1: Verifica file JSON valido
        $dataFile = '/var/www/lightbot.rentri360.it/private/user_limits.json';
        
        if (file_exists($dataFile)) {
            $content = file_get_contents($dataFile);
            $jsonData = json_decode($content, true);
            
            $results['json_validity'] = [
                'valid' => json_last_error() === JSON_ERROR_NONE,
                'error' => json_last_error_msg(),
                'file_size' => filesize($dataFile)
            ];
            
            if (json_last_error() === JSON_ERROR_NONE) {
                // Test struttura records
                $recordCount = 0;
                $validRecords = 0;
                
                foreach ($jsonData as $hash => $record) {
                    $recordCount++;
                    
                    $hasRequiredFields = isset($record['count']) &&
                                        isset($record['created']) &&
                                        isset($record['is_blocked']);
                    
                    if ($hasRequiredFields) {
                        $validRecords++;
                    }
                }
                
                $results['data_structure'] = [
                    'total_records' => $recordCount,
                    'valid_records' => $validRecords,
                    'integrity_ok' => $recordCount === $validRecords
                ];
            }
        } else {
            $results['json_validity'] = [
                'valid' => false,
                'error' => 'File does not exist'
            ];
        }
        
        // Test 2: Permissions
        $results['permissions'] = [
            'file_readable' => is_readable($dataFile),
            'file_writable' => is_writable($dataFile),
            'directory_writable' => is_writable(dirname($dataFile))
        ];
        
        // Test 3: Storage stats consistency
        $stats = $storage->getStorageStats();
        
        $results['stats_consistency'] = [
            'stats' => $stats,
            'total_matches_file' => true // Placeholder for detailed check
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'data_integrity',
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

/**
 * Test funzioni admin
 */
function testAdminFunctions($storage, $data) {
    $results = [];
    
    try {
        $testUserId = $data['test_user_id'] ?? ('fp_' . str_repeat('d', 64) . '_' . base_convert(time() * 1000, 10, 36));
        
        // Test 1: Generate admin token
        $adminToken = hash_hmac('sha256', 
            date('Y-m-d') . $testUserId, 
            'rentria_admin_secret_2025_' . $_SERVER['SERVER_NAME']
        );
        
        $results['admin_token'] = [
            'generated' => !empty($adminToken),
            'token_length' => strlen($adminToken),
            'token_preview' => substr($adminToken, 0, 16) . '...'
        ];
        
        // Test 2: Test bypass function
        $bypassResult = $storage->adminBypass($testUserId, $adminToken);
        
        $results['bypass_test'] = [
            'valid_token_accepted' => $bypassResult,
            'invalid_token_rejected' => !$storage->adminBypass($testUserId, 'invalid_token')
        ];
        
        // Test 3: Reset user (crea prima un utente con messaggi)
        for ($i = 0; $i < 3; $i++) {
            $storage->incrementUserMessageCount($testUserId);
        }
        
        $beforeReset = $storage->getUserRecord($testUserId);
        $resetResult = $storage->resetUser($testUserId, $adminToken);
        $afterReset = $storage->getUserRecord($testUserId);
        
        $results['reset_test'] = [
            'reset_executed' => $resetResult,
            'count_before' => $beforeReset['count'],
            'count_after' => $afterReset['count'],
            'properly_reset' => $afterReset['count'] === 0
        ];
        
    } catch (Exception $e) {
        $results['error'] = $e->getMessage();
    }
    
    return [
        'success' => !isset($results['error']),
        'test' => 'admin_functions',
        'results' => $results,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

?>