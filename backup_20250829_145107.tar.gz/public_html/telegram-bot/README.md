# 🤖 RentriFacileBot - Bot Telegram

Bot Telegram ufficiale per il gruppo @RentriFacile, integrato con l'assistente AI RentrIA specializzato nella gestione dei rifiuti e sistema RENTRI.

## 📋 Configurazione Iniziale

### 1. **Prerequisiti**
- Server web con PHP 7.4+
- Accesso HTTPS (richiesto da Telegram)
- Bot Telegram creato e token disponibile
- API AI configurata (stessa del chatbot web)

### 2. **Installazione**

```bash
# I file sono già stati creati in /var/www/html/telegram-bot/
cd /var/www/html/telegram-bot/

# Modifica le configurazioni
nano config.php
```

### 3. **Configurazione config.php**

Aggiorna i seguenti valori:

```php
// Inserisci la tua chiave API AI (stessa del chatbot web)
define('AI_API_KEY', 'la-tua-chiave-api-qui');
define('AI_AGENT_ID', 'il-tuo-agent-id-qui');

// Inserisci l'URL del tuo webhook
define('WEBHOOK_URL', 'https://tuodominio.com/telegram-bot/webhook.php');

// Aggiungi User ID degli amministratori
define('BOT_ADMINS', [
    123456789, // Sostituisci con i tuoi User ID
]);
```

### 4. **Avvio Sistema**

Il sistema usa polling HTTP (non webhook) ed è già pronto all'uso:

```bash
./start-bot.sh  # Avvia bot in background
./stop-bot.sh   # Ferma bot
```

## 🏠 Configurazione Gruppo Telegram

### **Passaggi per il Gruppo @RentriFacile:**

1. **Aggiungi il Bot al Gruppo**
   - Vai su https://t.me/RentriFacile
   - Clicca "Aggiungi membri"
   - Cerca "@RentriFacileBot"
   - Aggiungi il bot

2. **Configura Permessi (Opzionale)**
   - Rendi il bot amministratore se vuoi funzioni avanzate
   - Permessi minimi: "Eliminare messaggi" per gestione errori

3. **Test Funzionalità**
   ```
   @RentriFacileBot /start
   @RentriFacileBot ciao, come funziona l'affitto?
   ```

## 📱 Comandi Disponibili

### **Comandi Pubblici:**
- `/start` - Messaggio di benvenuto e introduzione
- `/help` - Lista completa comandi disponibili  
- `/info` - Informazioni sul bot e versione
- `/contatti` - Informazioni di contatto RentriFacile
- `/sito` - Link diretto al sito web

### **Comandi Amministratore:**
- `/stats` - Statistiche utilizzo bot
- `/broadcast <messaggio>` - Messaggio broadcast a tutti gli utenti
- `/status` - Stato sistema e connessioni

### **Comandi Futuri (In Sviluppo):**
- `/classifica <descrizione>` - Classificazione automatica rifiuti
- `/normativa <tipo>` - Consulta normative ambientali
- `/moduli` - Accesso ai moduli RENTRI
- `/codici` - Cerca codici CER/EWC
- `/smaltimento` - Procedure di smaltimento
- `/trasporto` - Normative trasporto rifiuti
- `/adr` - Informazioni regolamento ADR
- `/formulari` - Gestione formulari identificazione rifiuti
- `/registri` - Tenuta registri di carico/scarico
- `/audit` - Verifiche conformità ambientale

## 🔧 Funzionalità Implementate

### **Gestione Messaggi**
- ✅ Risposte solo quando menzionato: `@RentriFacileBot`
- ✅ Risposte in chat private
- ✅ Risposte quando si risponde ai messaggi del bot
- ✅ Integrazione completa con AI RentrIA

### **Sicurezza**
- ✅ Protezione file di configurazione
- ✅ Rate limiting messaggi
- ✅ Logging completo attività
- ✅ Gestione errori robusta

### **Monitoraggio**
- ✅ Log dettagliati in `logs/bot.log`
- ✅ Statistiche amministratore
- ✅ Stato sistema in tempo reale

## 📁 Struttura File

```
telegram-bot/
├── config.php          # Configurazione bot e API  
├── polling-bot.php     # Handler principale messaggi (polling)
├── bot-functions.php   # Funzioni core del bot
├── start-bot.sh        # Script avvio bot
├── stop-bot.sh         # Script stop bot
├── .htaccess          # Protezioni sicurezza
├── README.md          # Questa documentazione
└── logs/
    ├── bot.log        # Log attività bot
    ├── bot-output.log # Output del bot
    └── bot.pid        # Process ID del bot
```

## 🚀 Come Usare il Bot

### **Per gli Utenti del Gruppo:**

1. **Fai una Domanda:**
   ```
   @RentriFacileBot come classifico i rifiuti da demolizione?
   @RentriFacileBot quali sono i codici CER per plastica contaminata?
   ```

2. **Usa i Comandi:**
   ```
   /help
   /rifiuti
   /contatti
   /sito
   ```

3. **Chat Privata:**
   - Scrivi direttamente al bot senza menzionarlo
   - Ottieni risposte immediate

### **Per gli Amministratori:**

1. **Monitora Statistiche:**
   ```
   /stats - Visualizza utilizzo
   /status - Controlla stato sistema
   ```

2. **Gestisci Comunicazioni:**
   ```
   /broadcast Messaggio importante per tutti
   ```

## 🔧 Manutenzione

### **Log e Debug:**
```bash
# Visualizza log in tempo reale
tail -f /var/www/html/telegram-bot/logs/bot.log

# Controlla errori PHP
tail -f /var/log/apache2/error.log
```

### **Test Bot:**
```bash
# Controlla se il bot è attivo
ps aux | grep polling-bot

# Verifica log per errori
tail -f logs/bot.log
```

### **Aggiornamenti:**
- Modifica `config.php` per nuove configurazioni
- Riavvia bot con `./stop-bot.sh && ./start-bot.sh`
- Monitora `logs/bot.log` per errori

## 🔮 Sviluppi Futuri

### **Database Integration:**
- Gestione utenti registrati  
- Statistiche utilizzo sistema RENTRI
- Preferenze classificazione rifiuti

### **Funzioni Avanzate:**
- Classificazione automatica rifiuti
- Sistema notifiche normative
- Gestione scadenze ambientali
- Upload foto rifiuti per riconoscimento

### **Integrazioni:**
- Sistema nazionale RENTRI
- Database codici CER/EWC
- Normative ambientali aggiornate
- API classificazione automatica

## 📞 Supporto

- **Gruppo:** @RentriFacile
- **Bot:** @RentriFacileBot  
- **Sito:** PiattaformaRentriFacile.it
- **Log:** `/var/www/html/telegram-bot/logs/bot.log`

---

*Bot sviluppato con Claude Code - RentrIA © 2024*