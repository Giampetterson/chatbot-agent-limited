<?php
/**
 * Configurazione Bot Telegram RentriFacileBot
 * 
 * IMPORTANTE: Non committare mai questo file con credenziali reali!
 * Usa variabili d'ambiente in produzione.
 */

// Configurazione Bot Telegram
define('TELEGRAM_BOT_TOKEN', '8105155308:AAFLNStazvpGz6j-ntEArmyyMWv1jZewkhs');
define('TELEGRAM_API_URL', 'https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN);

// Configurazione Gruppo
define('TELEGRAM_GROUP_ID', '@RentriFacile'); // Username del gruppo
define('TELEGRAM_GROUP_URL', 'https://t.me/RentriFacile');

// Configurazione Webhook
define('WEBHOOK_URL', 'https://chatbot-test.piattaformarentrifacile.it/telegram-bot/webhook.php');

// Configurazione AI (stessa del chatbot web)
define('AI_API_URL', 'https://s5pdsmwvr6vyuj6gwtaedp7g.agents.do-ai.run/api/v1/chat/completions');
define('AI_API_KEY', 'YPKwjwUhsEj6ygLXZ_G_NK1ugxOZ7XrS');
define('AI_AGENT_ID', '5cec402c-6f7b-11f0-bf8f-4e013e2ddde4');

// Configurazione Sistema
define('LOG_FILE', __DIR__ . '/logs/bot.log');
define('DEBUG_MODE', true);

// Amministratori Bot (User IDs Telegram)
define('BOT_ADMINS', [
    // 123456789, // Aggiungi qui gli User ID degli amministratori
]);

// Limiti e Configurazioni
define('MAX_MESSAGE_LENGTH', 4096); // Limite Telegram per messaggi
define('REQUEST_TIMEOUT', 30);      // Timeout per richieste AI
define('RATE_LIMIT_SECONDS', 2);    // Limite velocità messaggi

// Database (opzionale per statistiche future)
define('DB_HOST', 'localhost');
define('DB_NAME', 'telegram_bot');
define('DB_USER', 'telegram_user');
define('DB_PASS', 'telegram_password');

?>